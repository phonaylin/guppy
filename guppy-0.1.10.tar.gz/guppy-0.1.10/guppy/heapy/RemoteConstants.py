# Constants used in communication between RemoteAccess and Monitor

READLINE = 'READLINE\n'
KEYBOARDINTERRUPT = 'KEYBOARDINTERRUPT\n'
DONE = 'DONE\n'
LOCALHOST = '127.0.0.1'
#HEAPYPORT = 8834
HEAPYPORT = 3546

