# Start a remote monitoring enabling thread,
# unless I am that thread myself.

from guppy.heapy.Remote import on
on()


